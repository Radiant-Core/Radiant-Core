Radiant Core macOS ARM64 Binaries v2.3.0
=========================================

Files Included:
--------------
  radiantd      - Main Radiant Core daemon
  radiant-cli   - RPC client utility
  radiant-tx    - Transaction utility

System Requirements:
-------------------
  macOS 11.0 (Big Sur) or later, Apple Silicon (ARM64)

Quick Start:
-----------
  chmod +x radiantd radiant-cli radiant-tx
  ./radiantd
  ./radiant-cli getblockchaininfo

For more information: https://radiantblockchain.org
