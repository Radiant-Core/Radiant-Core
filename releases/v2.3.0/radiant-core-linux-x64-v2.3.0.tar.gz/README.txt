Radiant Core Linux x64 Binaries v2.3.0
=======================================

Files Included:
--------------
  radiantd      - Main Radiant Core daemon
  radiant-cli   - RPC client utility
  radiant-tx    - Transaction utility

System Requirements:
-------------------
  Linux x86_64, glibc 2.35+ (Ubuntu 22.04+)

Quick Start:
-----------
  chmod +x radiantd radiant-cli radiant-tx
  ./radiantd
  ./radiant-cli getblockchaininfo

For more information: https://radiantblockchain.org
